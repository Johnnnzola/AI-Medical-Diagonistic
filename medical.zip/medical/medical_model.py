# ==============================================================================
# 1. DATABASE DATA LOADING (REPLACING CSV LOADING)
# ==============================================================================
import sqlalchemy
import pandas as pd

# Database configuration (Change these)
DB_USER = 'your_mysql_user'
DB_PASSWORD = 'your_mysql_password'
DB_HOST = 'localhost'
DB_NAME = 'medical_records'
MAIN_TABLE = 'all_patient_data' # Assuming you've created and populated one table

# Create the connection engine
try:
    engine = sqlalchemy.create_engine(
        f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}@{DB_HOST}/{DB_NAME}"
    )
    
    # Load all data into df_master
    # NOTE: Your data MUST be pre-merged/pre-joined into the MAIN_TABLE
    query = f"SELECT * FROM {MAIN_TABLE}"
    df_master = pd.read_sql(query, con=engine)
    
    # Assuming 'Patient_ID' is the primary key in your DB table
    df_master = df_master.rename(columns={'Patient_ID': 'Patient_ID'}).set_index('Patient_ID')
    df_master = df_master.reset_index(drop=True)

    print(f"Data loaded successfully from MySQL table: {MAIN_TABLE}. Shape: {df_master.shape}")
    
except Exception as e:
    print(f"Error connecting to or loading data from the database: {e}")
    # Fallback to the old method if DB is unavailable, or exit
    raise RuntimeError("Failed to load data from the database.") 

# Continue with Section 3: Data Cleaning and Preparation...
# The rest of the script (Cleaning, Training, Saving Models) remains the same.


# ==============================================================================
# 3. DATA CLEANING AND PREPARATION (STABLE)
# ==============================================================================

df_master.dropna(axis=1, how='all', inplace=True)
print("Shape of the DataFrame after dropping empty columns:", df_master.shape)

df_master.drop(columns=['Patient_ID'], errors='ignore', inplace=True)

# Drop highly unique/non-predictive columns
cols_to_drop = [
    col for col in df_master.columns if any(
        keyword in col for keyword in ['_DATE', '_NAME', '_AGE', 'Text65', 'Text67', 'Text68']
    )
]
df_master.drop(columns=cols_to_drop, errors='ignore', inplace=True)
print(f"Dropped {len(cols_to_drop)} high-cardinality columns.")


# --- Target Definition ---

# Define disease target columns (Classification Targets)
disease_cols_keywords = ['BRUCELLA', 'HEPB', 'HEPC', 'HIV', 'SALMONELLA', 'SYPHILIS']
disease_cols = [
    col for col in df_master.columns if any(test in col for test in disease_cols_keywords) and any(result_type in col for result_type in ['RESULTS', 'PN RESULTS', 'BAT RESULTS'])
]

if not disease_cols:
    raise ValueError("No disease target columns found. Check column names/keywords.")

y_disease = df_master[disease_cols].apply(pd.to_numeric, errors='coerce').fillna(0).astype(int)


# Define lab result target columns (Regression Targets)
# 🚨 Re-defining the list with the confirmed working targets and the original preferred names. 🚨
lab_target_map = {
    'BILIRUBIN_BIL RESULTS': ['BILIRUBIN'],
    'FULLHAEMOGLOBIN_HB': ['FULLHAEMOGLOBIN', 'HB'],
    'KIDNEY_Creat': ['KIDNEY', 'Creat'],
    'LIPID_CHOLESTEROL': ['LIPID', 'CHOLESTEROL'],
    'LIVER_ALBUMIN L': ['LIVER', 'ALBUMIN'],
    'THYROID_TSH': ['THYROID', 'TSH'],
    'URIC_LEVEL': ['URIC']
}

y_lab_numeric_cols = []
final_target_names = []

for standard_name, keywords in lab_target_map.items():
    # Attempt to find the column by keywords
    # Prioritize columns that contain ALL keywords, then just the prefix, and must be numeric after coercion
    
    # 1. Coerce to numeric for reliable check
    df_temp = df_master[[col for col in df_master.columns if keywords[0] in col]].apply(pd.to_numeric, errors='coerce')
    
    # 2. Filter for columns that are mostly numeric (less than 50% NaN)
    numeric_matches = df_temp.columns[df_temp.isnull().mean() < 0.5].tolist()
    
    # 3. Use the first column that matches the prefix and is numeric.
    if numeric_matches:
        # Sort to pick the best match (often the one with shortest name or specific keyword)
        match = next((col for col in numeric_matches if all(k in col for k in keywords)), numeric_matches[0])
        y_lab_numeric_cols.append(match)
        final_target_names.append(standard_name)
    else:
        print(f"⚠️ Warning: Could not find a suitable numeric column for target '{standard_name}'. Skipping.")

if not y_lab_numeric_cols:
    run_stage_2 = False
    print("WARNING: No robust numeric lab result columns found. Skipping Stage 2 (Lab Prediction).")
else:
    run_stage_2 = True
    # Select, fill, and rename the columns
    y_lab_numeric = df_master[y_lab_numeric_cols].apply(pd.to_numeric, errors='coerce').fillna(df_master[y_lab_numeric_cols].apply(pd.to_numeric, errors='coerce').median())
    y_lab_numeric.columns = final_target_names


# --- Feature Engineering (X) ---
cols_to_drop_x = disease_cols + y_lab_numeric_cols
X = df_master.drop(columns=cols_to_drop_x, errors='ignore')

# Separate X into numerical and categorical for imputation/encoding
X_numeric_cols = X.select_dtypes(include=['int64', 'float64']).columns
X_categorical_cols = X.select_dtypes(include=['object']).columns

# Coerce object types in X to string before get_dummies (best practice)
X[X_categorical_cols] = X[X_categorical_cols].astype(str).fillna('Unknown')

# Impute and Encode X
X[X_numeric_cols] = X[X_numeric_cols].fillna(X[X_numeric_cols].median())
X = pd.get_dummies(X, columns=X_categorical_cols, dummy_na=False, drop_first=True)


print("\nFeatures (X) shape after reduction and encoding:", X.shape)
print("Disease Targets (y_disease) shape:", y_disease.shape)
if run_stage_2:
    print("Lab Targets (y_lab_numeric) shape:", y_lab_numeric.shape)


# ==============================================================================
# 4. STAGE 1: DISEASE PREDICTION MODEL (MultiOutputClassifier)
# ==============================================================================

print("\n--- Starting Stage 1: Disease Prediction (Optimized) ---")

# Stage 1 split
X_train, X_test, y_train, y_test = train_test_split(
    X, y_disease, test_size=0.2, random_state=42
)

# Train MultiOutputClassifier (using increased n_estimators and class_weight)
# 🚨 FIX for zero scores: Using 'balanced' to prioritize finding the rare positive class 
disease_model = MultiOutputClassifier(RandomForestClassifier(n_estimators=N_ESTIMATORS_OPTIMIZED, random_state=42, n_jobs=-1, class_weight='balanced'))
disease_model.fit(X_train, y_train)

# Evaluate stage 1
y_pred_test = disease_model.predict(X_test)
print("\n=== Stage 1: Disease Prediction Evaluation ===")
# Ensure targets are aligned for the report
if y_test.sum().sum() == 0:
    print("WARNING: No positive cases in the test set. Scores are unreliable/zero.")
print(classification_report(y_test, y_pred_test, target_names=y_disease.columns, zero_division=0))

# Predict diseases for the full dataset (for stage 2 features)
y_pred_full = disease_model.predict(X)
y_pred_full_df = pd.DataFrame(y_pred_full, columns=[f'Predicted_{col}' for col in y_disease.columns])


# ==============================================================================
# 5. STAGE 2: LAB RESULT PREDICTION MODEL (MultiOutputRegressor)
# ==============================================================================

if run_stage_2:
    print("\n--- Starting Stage 2: Lab Prediction (Optimized) ---")

    # --- Create Stage 2 Features ---
    X_reset = X.reset_index(drop=True)
    y_pred_full_df_reset = y_pred_full_df.reset_index(drop=True)
    y_lab_numeric_reset = y_lab_numeric.reset_index(drop=True)
    
    X_second_stage = pd.concat([X_reset, y_pred_full_df_reset], axis=1)

    X2_train, X2_test, y2_train, y2_test = train_test_split(
        X_second_stage, 
        y_lab_numeric_reset, 
        test_size=0.2, 
        random_state=42
    )

    # Train MultiOutputRegressor (using increased n_estimators)
    lab_model = MultiOutputRegressor(RandomForestRegressor(n_estimators=N_ESTIMATORS_OPTIMIZED, random_state=42, n_jobs=-1))
    lab_model.fit(X2_train, y2_train)

    # Predict lab results and Evaluate stage 2
    y2_pred = lab_model.predict(X2_test)

    print("\n=== Stage 2: Lab Result Prediction Evaluation ===")
    for i, col in enumerate(y2_train.columns):
        mse = mean_squared_error(y2_test[col], y2_pred[:, i])
        r2 = r2_score(y2_test[col], y2_pred[:, i])
        print(f"'{col}': MSE={mse:.4f}, R²={r2:.4f}")


# ==============================================================================
# 6. MODEL AND FEATURE SAVING
# ==============================================================================

print("\nSaving models and feature lists...")

# Save Stage 1 model
joblib.dump(disease_model, "disease_model.pkl")
joblib.dump(X.columns.tolist(), "stage1_features.pkl")
joblib.dump(y_disease.columns.tolist(), "stage1_targets.pkl")

if run_stage_2:
    # Save Stage 2 model
    joblib.dump(lab_model, "lab_model.pkl")
    joblib.dump(X_second_stage.columns.tolist(), "stage2_features.pkl")
    joblib.dump(y_lab_numeric.columns.tolist(), "stage2_targets.pkl")

print("Models and feature lists saved successfully to current directory.")