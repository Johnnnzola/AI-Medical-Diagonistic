// predict.php

// 1. Configuration (Add DB Config)
$api_url = 'http://127.0.0.1:5000/predict'; 

// MySQL Configuration
$db_host = 'localhost';
$db_user = 'your_mysql_user';
$db_password = 'your_mysql_password';
$db_name = 'medical_records';
$main_table = 'all_patient_data';

// ... (Prepare data from POST request)

// 2. Database Connection and Insertion (Using MySQLi)
$conn = new mysqli($db_host, $db_user, $db_password, $db_name);
if ($conn->connect_error) {
    die("Database Connection failed: " . $conn->connect_error);
}

// Convert input data to SQL format (simplified, assumes all keys are columns)
// *** NOTE: You must sanitize and validate all input before using it in SQL ***
$columns = implode(", ", array_keys($input_data));
$placeholders = implode(", ", array_fill(0, count($input_data), '?'));

$stmt = $conn->prepare("INSERT INTO $main_table ($columns) VALUES ($placeholders)");

// Dynamically bind parameters (more complex in pure PHP, but safer)
$types = str_repeat('s', count($input_data)); // Assuming all inputs are strings for simplicity
$stmt->bind_param($types, ...array_values($input_data));

if ($stmt->execute()) {
    echo "<p>Patient data saved to database successfully.</p>";
} else {
    echo "<p>Warning: Could not save data to database. Error: " . $stmt->error . "</p>";
}
$stmt->close();
$conn->close();

// 3. Send Request to Flask API (Remains the same)...
// ...