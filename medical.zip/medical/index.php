<?php
// index.php - This file serves the patient data input form.

// Define default values or options for the form elements
$blood_groups = ['A+', 'B+', 'O+', 'AB+', 'A-', 'B-', 'O-', 'AB-', 'Unknown'];
$rheumatoid_options = ['Positive', 'Negative', 'Pending'];
$default_values = [
    'BILIRUBIN_BILI' => 1.1,
    'KIDNEY_CREATININE' => 0.9, // Added a common input to demonstrate expansion
    'LIPID_CHOLESTEROL' => 4.5,
    'FBS_RESULTS' => 90.5,
    'URINALYSIS_COLOR' => 'Yellow',
    'RHEUMATOID_RESULTS' => 'Negative'
];

// Simple function to retrieve a default value
function getDefaultValue($key, $defaults) {
    return isset($defaults[$key]) ? $defaults[$key] : '';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Prediction Input</title>
    <!-- Load Tailwind CSS via CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        /* Custom styles for better readability and feel */
        body { font-family: 'Inter', sans-serif; background-color: #f4f7f9; }
        .card { box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05); }
    </style>
</head>
<body class="p-4 sm:p-8">

    <div class="max-w-4xl mx-auto bg-white p-6 sm:p-10 rounded-xl card">
        <header class="text-center mb-10">
            <h1 class="text-3xl sm:text-4xl font-extrabold text-blue-900 tracking-tight">
                AI Medical Diagnostic Input
            </h1>
            <p class="text-gray-500 mt-2 text-lg">Enter patient data to generate disease and lab result predictions.</p>
        </header>

        <form action="predict.php" method="POST" class="space-y-6">

            <!-- Instruction Banner -->
            <div class="p-4 bg-yellow-50 border-l-4 border-yellow-500 text-yellow-800 rounded-md">
                <p class="font-semibold">Input Requirement:</p>
                <p class="text-sm">Please ensure the values entered here are accurate raw measurements. These fields must match the column names in your database and the raw inputs expected by the Python API.</p>
            </div>

            <h2 class="text-2xl font-semibold text-blue-700 pt-4 border-b pb-2">1. Core Numeric Lab Results</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                
                <!-- BILIRUBIN_BILI -->
                <div>
                    <label for="BILIRUBIN_BILI" class="block text-sm font-medium text-gray-700">Bilirubin (mg/dL)</label>
                    <input type="number" step="0.1" id="BILIRUBIN_BILI" name="BILIRUBIN_BILI" 
                           value="<?php echo getDefaultValue('BILIRUBIN_BILI', $default_values); ?>" 
                           required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-3">
                </div>

                <!-- LIPID_CHOLESTEROL -->
                <div>
                    <label for="LIPID_CHOLESTEROL" class="block text-sm font-medium text-gray-700">Cholesterol (mmol/L)</label>
                    <input type="number" step="0.1" id="LIPID_CHOLESTEROL" name="LIPID_CHOLESTEROL" 
                           value="<?php echo getDefaultValue('LIPID_CHOLESTEROL', $default_values); ?>" 
                           required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-3">
                </div>
                
                <!-- FBS_RESULTS -->
                <div>
                    <label for="FBS_RESULTS" class="block text-sm font-medium text-gray-700">Fasting Blood Sugar (mg/dL)</label>
                    <input type="number" step="0.1" id="FBS_RESULTS" name="FBS_RESULTS" 
                           value="<?php echo getDefaultValue('FBS_RESULTS', $default_values); ?>" 
                           required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-3">
                </div>
                
                <!-- KIDNEY_CREATININE -->
                <div>
                    <label for="KIDNEY_CREATININE" class="block text-sm font-medium text-gray-700">Creatinine (mg/dL)</label>
                    <input type="number" step="0.01" id="KIDNEY_CREATININE" name="KIDNEY_CREATININE" 
                           value="<?php echo getDefaultValue('KIDNEY_CREATININE', $default_values); ?>" 
                           required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-3">
                </div>

            </div>

            <h2 class="text-2xl font-semibold text-blue-700 pt-4 border-b pb-2">2. Categorical & Other Data</h2>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">

                <!-- BLOOD_GROUP_RESULT -->
                <div>
                    <label for="BLOOD_GROUP_RESULT" class="block text-sm font-medium text-gray-700">Blood Group</label>
                    <select id="BLOOD_GROUP_RESULT" name="BLOOD_GROUP_RESULT" required 
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-3">
                        <?php foreach ($blood_groups as $group): ?>
                            <option value="<?php echo htmlspecialchars($group); ?>" 
                                    <?php if ($group === 'A+'): echo 'selected'; endif; ?>>
                                <?php echo htmlspecialchars($group); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <!-- URINALYSIS_COLOR -->
                <div>
                    <label for="URINALYSIS_COLOR" class="block text-sm font-medium text-gray-700">Urine Color</label>
                    <input type="text" id="URINALYSIS_COLOR" name="URINALYSIS_COLOR" 
                           value="<?php echo getDefaultValue('URINALYSIS_COLOR', $default_values); ?>" 
                           required class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-3" 
                           placeholder="e.g., Yellow, Amber, Clear">
                </div>
                
                <!-- RHEUMATOID_RESULTS -->
                <div>
                    <label for="RHEUMATOID_RESULTS" class="block text-sm font-medium text-gray-700">Rheumatoid Factor</label>
                    <select id="RHEUMATOID_RESULTS" name="RHEUMATOID_RESULTS" required 
                            class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 p-3">
                        <?php foreach ($rheumatoid_options as $option): ?>
                            <option value="<?php echo htmlspecialchars($option); ?>"
                                    <?php if ($option === 'Negative'): echo 'selected'; endif; ?>>
                                <?php echo htmlspecialchars($option); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

            </div>

            <!-- Submit Button -->
            <div class="pt-6">
                <button type="submit" 
                        class="w-full flex justify-center py-3 px-4 border border-transparent rounded-md shadow-lg 
                               text-lg font-medium text-white bg-green-600 hover:bg-green-700 
                               focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition duration-150 ease-in-out">
                    Save Data & Generate Prediction
                </button>
            </div>
            
        </form>
    </div>

</body>
</html>
