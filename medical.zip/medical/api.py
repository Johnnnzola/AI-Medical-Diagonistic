from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import pandas as pd
import numpy as np

app = Flask(__name__)
CORS(app)

# ==============================================================================
# 1. LOAD MODELS AND FEATURE/TARGET LISTS
# ==============================================================================
try:
    disease_model = joblib.load("disease_model.pkl")
    lab_model = joblib.load("lab_model.pkl")
    stage1_features = joblib.load("stage1_features.pkl")  # list of feature names for X1 (OHE features)
    stage2_features = joblib.load("stage2_features.pkl")  # list of feature names for X2 (X1 + predicted diseases)

    # Load the target names
    disease_target_names = joblib.load("stage1_targets.pkl")
    lab_target_names = joblib.load("stage2_targets.pkl")
    
    # Extract the names of the original, raw categorical and numeric columns 
    # This is done by reversing the OHE process for prediction preparation
    # Note: This is an estimation. It assumes features with underscores are OHE.
    # A safer approach would be to save these lists during training.
    # We will simply rely on aligning the final OHE DataFrame.
    
    print("Models and feature/target lists loaded successfully.")
except Exception as e:
    print("Error loading models or feature lists:", e)
    # The script will exit here if files are missing or corrupt
    exit(1)

# ==============================================================================
# 2. PREDICT ROUTE
# ==============================================================================

def prepare_features(input_df, feature_list):
    """
    Performs one-hot encoding on the input DataFrame and aligns columns
    with the model's required feature list.
    """
    
    # 1. Identify initial feature columns (numeric and object)
    # NOTE: This assumes the input data contains all the RAW columns used 
    # to generate the OHE features in the training script.
    
    # 2. Apply OHE (Must use the same columns as were categorical in training)
    # Since we don't know the exact categorical columns, we OHE all object types.
    # The training script used OHE on all object columns after dropping high-cardinality ones.
    
    # Handle numeric and categorical columns
    X_numeric_cols = input_df.select_dtypes(include=np.number).columns
    X_categorical_cols = input_df.select_dtypes(include='object').columns

    # Impute numeric with median (or 0 for API for safety)
    input_df[X_numeric_cols] = input_df[X_numeric_cols].fillna(0)
    
    # Impute categorical with 'Unknown' (as done in training)
    input_df[X_categorical_cols] = input_df[X_categorical_cols].astype(str).fillna('Unknown')
    
    # Apply One-Hot Encoding
    X_processed = pd.get_dummies(input_df, columns=X_categorical_cols, drop_first=True)

    # 3. Align with the required feature list (CRITICAL STEP)
    # Create a DataFrame with the exact columns the model expects.
    # Add missing OHE columns (set to 0) and drop extra ones.
    X_aligned = pd.DataFrame(0, index=X_processed.index, columns=feature_list)

    # Copy the values for the columns that exist in the processed input
    common_cols = list(set(X_processed.columns) & set(feature_list))
    X_aligned[common_cols] = X_processed[common_cols]

    return X_aligned

@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json(force=True)
        
        if not isinstance(data, dict):
            return jsonify({"error": "Invalid input data. Expected JSON object."}), 400

        # Create DataFrame from input data (single row)
        input_df = pd.DataFrame([data])

        # --- Stage 1 Feature Preparation and Prediction ---
        # Replicate the OHE and alignment process
        X1 = prepare_features(input_df.copy(), stage1_features)
        
        # NOTE: We can skip the 'missing1' check because 'prepare_features' handles it by 
        # setting missing OHE features (from the list) to 0. We assume the raw input 
        # contains the necessary base columns.

        disease_pred_array = disease_model.predict(X1)

        # --- Stage 2 Feature Preparation and Prediction ---
        
        # 1. Generate Predicted Features for Stage 2
        y_pred_df = pd.DataFrame(disease_pred_array, 
                                 columns=[f'Predicted_{col}' for col in disease_target_names], 
                                 index=X1.index)
        
        # 2. Create X2 by combining X1 (OHE features) and predicted diseases
        # This order matches the training script's X_second_stage
        X2 = pd.concat([X1, y_pred_df], axis=1)
        
        # 3. Align X2 columns with the exact order and names the lab model expects
        X2 = X2[stage2_features] 

        # Predict Lab Results (Stage 2)
        lab_pred_array = lab_model.predict(X2)

        # --- Format Output (Using Loaded Target Names) ---
        
        # 1. Disease Predictions
        diseases_out = {}
        for i, fname in enumerate(disease_target_names):
            val = disease_pred_array[0][i]
            # Assumes 1=Positive, 0=Negative
            diseases_out[fname] = "Positive" if (val == 1) else "Negative"

        # 2. Lab Results Predictions
        lab_out = {}
        for i, fname in enumerate(lab_target_names):
            # Convert prediction to float for JSON
            lab_out[fname] = float(lab_pred_array[0][i])

        response = {
            "diseases": diseases_out,
            "lab_results": lab_out
        }

        return jsonify(response), 200

    except Exception as e:
        # Generic error handling
        print(f"Prediction Error: {e}")
        return jsonify({"error": "An unexpected error occurred during prediction.", "details": str(e)}), 500

if __name__ == "__main__":
    # Ensure you set debug=False in production!
    app.run(debug=True, host="0.0.0.0", port=5000)