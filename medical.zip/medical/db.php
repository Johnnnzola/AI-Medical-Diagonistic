<?php
// db.php: Centralized configuration and database connection handler

// ====================================================================
// 1. DATABASE CONFIGURATION
// !! IMPORTANT: REPLACE THESE PLACEHOLDERS WITH YOUR ACTUAL CREDENTIALS !!
// ====================================================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // <-- Update your username
define('DB_PASSWORD', '');  // <-- Update your password
define('medical', 'medical_records'); 
define('MAIN_TABLE', 'all_patient_data'); 


/**
 * Establishes a connection to the MySQL database.
 * * Includes error logging and gracefully terminates the script if the 
 * connection cannot be established.
 * * @return mysqli The database connection object.
 */
function getDbConnection() {
    // Create connection
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);

    // Check connection
    if ($conn->connect_error) {
        // Log the detailed error (visible in PHP error logs)
        error_log("MySQL Connection Failed: " . $conn->connect_error);
        
        // Output a clean, user-friendly error message and halt execution
        http_response_code(500);
        die("Server Error: Unable to connect to the database.");
    }
    
    // Set character set for proper handling of text data
    if (!$conn->set_charset("utf8mb4")) {
        error_log("Error loading character set utf8mb4: " . $conn->error);
    }

    return $conn;
}

// To use this in predict.php, you would replace the configuration block 
// in predict.php with:
// require_once 'db.php';
// $conn = getDbConnection();
?>
